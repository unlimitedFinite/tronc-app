require 'test_helper'

class TroncRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
