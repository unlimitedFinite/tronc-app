require 'test_helper'

class EmployeeRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
