class ApplicationMailer < ActionMailer::Base
  default from: 'noreply@troncsystem.com'
  layout 'mailer'
end
