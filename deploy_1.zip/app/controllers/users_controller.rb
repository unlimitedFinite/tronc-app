class UsersController < ApplicationController

def confirm
  # byebug
end


end
